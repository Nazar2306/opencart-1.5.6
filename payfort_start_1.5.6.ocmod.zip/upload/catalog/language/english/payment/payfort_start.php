<?php
// Text
$_['text_title']				= 'Credit or Debit Card <br />(Click continue to enter your card details)';
$_['text_wait']					= 'Please wait!';
$_['text_credit_card']			= 'Credit Card Details';
$_['text_loading']				= 'Loading';